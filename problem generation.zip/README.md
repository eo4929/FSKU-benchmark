# FSKU - 금융보안 이해도 문제 생성 시스템

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.0+-red.svg)
![LangChain](https://img.shields.io/badge/LangChain-Latest-green.svg)

FSKU(Financial Security Knowledge Understanding)는 금융보안 전문가의 이해도를 평가하기 위한 벤치마크 문제를 자동으로 생성하는 AI 기반 시스템입니다.

## 📋 목차
- [개요](#-개요)
- [주요 기능](#-주요-기능)
- [시스템 아키텍처](#-시스템-아키텍처)
- [설치 방법](#-설치-방법)
- [사용 방법](#-사용-방법)
- [디렉토리 구조](#-디렉토리-구조)
- [설정 파일](#-설정-파일)
- [파일 설명](#-파일-설명)
- [문제 생성 프로세스](#-문제-생성-프로세스)
- [출력 형식](#-출력-형식)

## 🎯 개요

FSKU는 금융보안 분야에서 5년 이상 경력을 가진 전문가를 대상으로, 실무 역량을 평가할 수 있는 고품질 문제를 자동 생성합니다. LangChain 에이전트 프레임워크와 RAG(Retrieval-Augmented Generation) 기술을 활용하여 참조 문서 기반의 정확하고 전문적인 문제를 생성합니다.

### 타겟 사용자
- 금융보안 교육 담당자
- 인사평가 담당자
- 금융보안 자격증 출제 위원
- 금융보안 교육 콘텐츠 제작자

## ✨ 주요 기능

### 1. 다양한 AI 모델 지원
- **오픈소스 모델**: Gemma2, Qwen2:7B, Llama3.1 (Ollama 기반)
- **상용 모델**: GPT-4o, GPT-4, GPT-3.5 (OpenAI API)

### 2. RAG(검색 증강 생성) 옵션
- PDF 참조 문서를 FAISS 벡터스토어로 임베딩
- 도메인별 전문 지식을 활용한 문제 생성
- 출처 명시를 통한 신뢰성 확보

### 3. 웹 검색 기능
- Tavily API를 활용한 최신 정보 검색
- 금융보안 동향 반영

### 4. 체계적인 분야 분류
- **금융보안일반**: 금융 비즈니스, 금융보안관리체계, 전자금융보안, 개인정보보호
- **금융보안IT**: IT보안 일반, IT보안 심화
- **금융보안법률**: 전자금융, 정보통신, 개인정보보호, 전자서명, 신용정보
- **금융보안동향**: 최신 동향 (2024년 기준)

### 5. 자동 CSV 생성
- 생성된 문제를 구조화된 CSV 형식으로 저장
- 문제, 정답, 해설, 참고문헌 자동 분류

## 🏗 시스템 아키텍처

```
┌─────────────────┐
│  Streamlit UI   │
│   (FSQG.py)     │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│         LangChain Agent                 │
│  ┌──────────────┐  ┌─────────────────┐ │
│  │ Tavily Search│  │ FAISS Retriever │ │
│  │    (Web)     │  │   (RAG/PDF)     │ │
│  └──────────────┘  └─────────────────┘ │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│         LLM (Language Model)            │
│  ┌──────────────┐  ┌─────────────────┐ │
│  │ GPT-4/3.5    │  │ Ollama Models   │ │
│  │  (OpenAI)    │  │ (Open Source)   │ │
│  └──────────────┘  └─────────────────┘ │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────┐
│   Tools.py      │
│  (CSV 저장)      │
└─────────────────┘
```

## 🚀 설치 방법

### 1. 필수 요구사항
```bash
Python 3.8 이상
```

### 2. 의존성 패키지 설치
```bash
pip install streamlit
pip install openai
pip install langchain
pip install langchain-community
pip install langchain-openai
pip install faiss-cpu
pip install PyPDF2
pip install pandas
pip install deepl
pip install tavily-python
```

### 3. API 키 설정
Streamlit secrets 파일(`.streamlit/secrets.toml`)을 생성하고 다음 내용을 추가:

```toml
OPENAI_API_KEY = "your-openai-api-key"
TAVILY_API_KEY = "your-tavily-api-key"
DEEPL_API_KEY = "your-deepl-api-key"  # (선택사항)
```

### 4. Ollama 설치 (오픈소스 모델 사용 시)
```bash
# Ollama 설치 (https://ollama.ai)
ollama pull gemma2
ollama pull qwen2:7b
ollama pull llama3.1
```

## 💻 사용 방법

### 1. 애플리케이션 실행
```bash
cd "Version 2"
streamlit run FSQG.py
```

### 2. 웹 인터페이스 설정
1. **AI 모델 선택**: 상용 LLM 토글 활성화 후 원하는 모델 선택
2. **RAG 사용**: 참조 문서 기반 생성을 원하면 토글 활성화
3. **분야 선택**:
   - 대분류(Domain) 선택
   - 세부분류(Sub-domain) 선택
4. **문제 개수**: 1~5개 범위 내에서 선택
5. **문제 생성** 버튼 클릭

### 3. 결과 확인
- 화면에 생성된 문제가 표시됩니다
- `{Domain}_{Sub_domain}.csv` 파일로 자동 저장됩니다

## 📂 디렉토리 구조

```
Version 2/
├── FSQG.py                    # 메인 애플리케이션
├── tools.py                   # 유틸리티 함수
├── prompt.py                  # 프롬프트 템플릿
├── README.md                  # 프로젝트 설명서
│
├── criteria/                  # 출제 기준 CSV 파일
│   ├── fs_basic/              # 금융보안일반
│   │   ├── biz.csv
│   │   ├── manage.csv
│   │   ├── elecfn.csv
│   │   └── infosec.csv
│   ├── fs_it/                 # 금융보안IT
│   │   ├── general.csv
│   │   └── advanced.csv
│   ├── fs_law/                # 금융보안법률
│   │   ├── elecfn.csv
│   │   ├── comm.csv
│   │   ├── infosec.csv
│   │   ├── elecsign.csv
│   │   └── credit.csv
│   └── fs_trend/              # 금융보안동향
│       └── 2024.csv
│
├── refer/                     # 참조 문서 (PDF)
│   ├── fs_basic/
│   ├── fs_it/
│   ├── fs_law/
│   └── fs_trend/
│
└── data/                      # 임베딩 벡터스토어
    ├── fs_basic/
    ├── fs_it/
    ├── fs_law/
    └── fs_trend/
```

## ⚙ 설정 파일

### criteria/*.csv
각 세부 분야별 출제 기준 키워드를 정의한 CSV 파일입니다. 각 행이 하나의 검색 키워드로 사용됩니다.

**예시:**
```csv
keyword1,keyword2,keyword3
전자금융거래,보안,인증
```

### refer/*.pdf
문제 생성 시 참조할 PDF 문서들을 배치합니다. RAG 기능 활성화 시 자동으로 임베딩되어 `data/` 디렉토리에 벡터스토어로 저장됩니다.

## 📄 파일 설명

### FSQG.py (메인 애플리케이션)
**주요 컴포넌트:**
- **라인 37-56**: Streamlit UI 구성 (모델 선택, RAG 옵션)
- **라인 65-148**: 분야별 경로 설정 로직
- **라인 154-159**: LLM 모델 초기화
- **라인 162-185**: 도구(Tool) 설정 (웹검색, RAG)
- **라인 187-202**: LangChain 에이전트 구성
- **라인 206-250**: 문제 생성 메인 로직

**핵심 로직:**
```python
for index, row in data.iterrows():
    search_keyword = row.tolist()
    query = f"Please create {problem_num} questions based on {search_keyword}"
    response = agent_executor.invoke({"input": query})
    all_questions += response["output"]
```

### tools.py (유틸리티)
**주요 함수:**

#### `make_a_embeddingData(refer_file_path, vectorstore_path)`
- PDF 문서 병합 및 임베딩 생성
- FAISS 벡터스토어로 저장
- **파라미터:**
  - `refer_file_path`: 참조 PDF 디렉토리 경로
  - `vectorstore_path`: 벡터스토어 저장 경로

#### `save_to_csv(output_data, domain, sub_domain)`
- LLM 출력에서 문제 요소 추출
- CSV 파일로 저장
- **파라미터:**
  - `output_data`: LLM 생성 텍스트
  - `domain`, `sub_domain`: 분야 정보

**정규식 패턴:**
```python
question_pattern = r"\[Question\s*\d*\]\s*(.*?)\s*\[Answer\]"
answer_pattern = r"\[Answer\](.*?)\[Explanation \(detailed\)\]"
explanation_pattern = r"\[Explanation \(detailed\)\](.*?)\[Refer to, quote\]"
reference_pattern = r"\[Refer to, quote\](.*?)(?=\[Question|\Z)"
```

### prompt.py (프롬프트 템플릿)
**구성 요소:**

#### `system_prompt_template`
- 역할 정의: 금융보안 전문가 평가자
- 대상: 5년+ 경력 실무자
- 난이도: 숙련자 선발 수준

#### `instructions` (23개 규칙)
1. 한국어 작성
2. 명확한 정답 요구
3. 문제에 정답 미포함
4. 객관식 4지선다
5. 정답 1개
6. 상세한 해설 제공
7. 참고문헌 필수
8. 부정문 최소화 (불가피시 밑줄)
9. 모든 오답이 그럴듯해야 함
10. 답지 길이 유사

#### `question_example` (17개 형식 가이드)
- 문항 번호: 1, 2, 3
- 선택지 번호: ①, ②, ③, ④
- 인용 표기: 문장 "", 구절 ""
- 부정문 처리: 해당 부분 밑줄
- 출처 표기: 데이터 우측 하단

#### `refer_questions` (예시 문제 유형)
```
다음 중 ㅇㅇㅇ에 해당하는 것은?
ㅇㅇㅇ에 대한 설명으로 가장 적절한 것은?
다음의 설명 중 옳은 것을 모두 고르시오.
```

## 🔄 문제 생성 프로세스

```
1. 사용자 입력
   ↓
2. CSV 기준 파일 로드
   ↓
3. 각 행(키워드)별 반복
   ↓
4. LangChain 에이전트 실행
   ├─→ Tavily 웹 검색 (최신 정보)
   └─→ FAISS RAG 검색 (참조 문서)
   ↓
5. LLM 문제 생성
   ├─ 프롬프트 주입 (system_prompt + instructions)
   ├─ 도구 활용 (검색 결과 반영)
   └─ 형식 준수 ([Question], [Answer], ...)
   ↓
6. 정규식 파싱
   ↓
7. CSV 저장
   ↓
8. UI 표시
```

## 📊 출력 형식

### 화면 출력
```
[Question 1]
전자금융거래법상 접근매체에 대한 설명으로 옳지 않은 것은?
① 전자식 카드 및 이에 준하는 전자적 정보
② 전자서명법에 따른 전자서명생성정보
③ 금융기관 또는 전자금융업자에 등록된 이용자번호
④ 이용자의 생체정보

[Answer]
②

[Explanation (detailed)]
전자금융거래법 제2조 제10호에서 접근매체를 정의하고 있으며,
전자서명생성정보는 전자서명법의 대상이지 접근매체에 해당하지 않습니다.
① 전자식 카드는 접근매체의 대표적인 예입니다.
③ 이용자번호는 계좌번호, ID 등을 포함합니다.
④ 생체정보는 지문, 홍채 등 본인 확인에 사용됩니다.

[Refer to, quote]
전자금융거래법 제2조(정의) 제10호
```

### CSV 출력 (예: 금융보안법률_전자금융.csv)
| Domain | Sub_domain | Question | Answer | Explanation (detailed) | Refer to, quote |
|--------|-----------|----------|--------|----------------------|----------------|
| 금융보안법률 | 전자금융 | 전자금융거래법상... | ② | 전자금융거래법 제2조... | 전자금융거래법 제2조... |

## 🔧 고급 설정

### RAG 임베딩 재생성
기존 벡터스토어 삭제 후 재실행:
```bash
rm -rf data/fs_basic/biz/embedding_data
# 애플리케이션 실행 시 자동 재생성
```

### 출제 기준 커스터마이징
`criteria/` 디렉토리의 CSV 파일을 편집하여 검색 키워드를 수정할 수 있습니다.

### 프롬프트 튜닝
`prompt.py` 파일을 수정하여 문제 생성 스타일을 조정할 수 있습니다.

## 📝 라이선스

이 프로젝트는 금융보안 교육 및 평가 목적으로 개발되었습니다.

## 🤝 기여

문제가 발견되거나 개선 사항이 있다면 Issue를 등록해주세요.

## 📧 문의

프로젝트 관련 문의사항이 있으시면 담당자에게 연락해주세요.

---

**버전**: 2.0
