# tools.py

from PyPDF2 import PdfMerger
from langchain_community.document_loaders import PyPDFLoader
import re
import pandas as pd
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import DirectoryLoader
import os

def make_a_embeddingData(refer_file_path, vectorstore_path):
    # 1. 참조 문서 파일 병합
    output_file = refer_file_path + "merge_file.pdf"
    
    merger = PdfMerger()
    file_list = sorted(os.listdir(refer_file_path))
    
    if not os.path.exists(output_file):
        if len(file_list) > 1:
            for filename in sorted(os.listdir(refer_file_path)):
                if filename.endswith('.pdf'):
                    file_path = os.path.join(refer_file_path, filename)
                    merger.append(file_path)

            merger.write(output_file)
            merger.close()
        else:
            output_file = refer_file_path + file_list[0]
        
        print("finish merger")

    # 2. 파일 임베딩
    loader = PyPDFLoader(output_file)
    documents = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    split_docs = text_splitter.split_documents(documents)
    
    embeddings = OpenAIEmbeddings()
    vector = FAISS.from_documents(split_docs, embeddings)
    vector.save_local(vectorstore_path)

def safe_extract_multiple(pattern, output_data):
    return [match[0] if isinstance(match, tuple) else match for match in re.findall(pattern, output_data, re.DOTALL)]

def save_to_csv(output_data, domain, sub_domain):    

    question_number_pattern = r"\[Question\s*(\d*)\]"  
    question_pattern = r"\[Question\s*\d*\]\s*(.*?)\s*\[Answer\]"

    question_numbers = safe_extract_multiple(question_number_pattern, output_data)
    question_texts = safe_extract_multiple(question_pattern, output_data)

    questions = [f"{num}. {text.strip()}" if num else text.strip() for num, text in zip(question_numbers, question_texts)]
    
    answer_pattern = r"\[Answer\](.*?)\[Explanation \(detailed\)\]"
    explanation_pattern = r"\[Explanation \(detailed\)\](.*?)\[Refer to, quote\]"
    reference_pattern = r"\[Refer to, quote\](.*?)(?=\[Question|\Z)"

    answers = safe_extract_multiple(answer_pattern, output_data)
    explanations = safe_extract_multiple(explanation_pattern, output_data)
    references = safe_extract_multiple(reference_pattern, output_data)

    max_length = max(len(questions), len(answers), len(explanations), len(references))
    questions += [""] * (max_length - len(questions))
    answers += [""] * (max_length - len(answers))
    explanations += [""] * (max_length - len(explanations))
    references += [""] * (max_length - len(references))

    print_data = []
    for i in range(max_length):
        print_data.append({
            'Domain': domain,
            'Sub_domain': sub_domain,
            'Question': questions[i].strip(),
            'Answer': answers[i].strip(),
            'Explanation (detailed)': explanations[i].strip(),
            'Refer to, quote': references[i].strip()
        })

    df = pd.DataFrame(print_data)

    csv_file_path = f"{domain}_{sub_domain}.csv"
    
    df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')