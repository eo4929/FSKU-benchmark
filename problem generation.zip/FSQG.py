# FSQG.py

# necessary library
import streamlit as st
import random
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import pandas as pd
import deepl

# related file
from tools import *
from prompt import *

# AI model
from openai import OpenAI
from langchain_community.chat_models import ChatOllama
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.agents import AgentExecutor
from langchain.agents import create_openai_functions_agent

# tools
from langchain_openai import OpenAIEmbeddings
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.vectorstores import FAISS
from langchain.tools.retriever import create_retriever_tool

# prompt
from langchain.prompts import MessagesPlaceholder

import random
from time import sleep


# 화면 구성
st.set_page_config(
    layout="wide",
)
st.title("금융보안 이해도 문제 생성")

# 1. AI 모델 선택
ai_model_type = st.toggle(label = "상용 LLM", 
                          key = "ai_model_flag", 
                          value = 0,
                          label_visibility = "visible",)

st.session_state['model_option'] = "None"
if ai_model_type == False:
    st.session_state['model_option'] = st.selectbox(
        "AI 모델 선택",
        ("gemma2", "qwen2:7B", "llama3.1"),)
else:
    st.session_state['model_option'] = st.selectbox(
        "AI 모델 선택",
        ("gpt-4o", "gpt-4", "gpt-3.5"),)

# 2. RAG 사용 여부
use_rag = st.toggle(label = "RAG 사용", 
                    key = "rag_use_flag", 
                    value = 0,
                    label_visibility = "visible",) 
        

# 3. 분야(domain, sub_domain) 선택
domain_list = ['금융보안일반', '금융보안IT', '금융보안법률', '금융보안동향']
st.session_state['domain'] = st.selectbox(
    "문제를 출제할 분야를 선택해주세요.",
    domain_list,)

if st.session_state['domain'] == domain_list[0]:
    sub_domain_list = ['금융 비즈니스', '금융보안관리체계', '전자금융보안', '개인정보보호']
elif st.session_state['domain'] == domain_list[1]:
    sub_domain_list = ['금융IT보안 일반', '금융IT보안 심화']
elif st.session_state['domain'] == domain_list[2]:
    sub_domain_list = ['전자금융', '정보통신', '개인정보보호', '전자서명', '신용정보']
elif st.session_state['domain'] == domain_list[3]:
    sub_domain_list = ['금융보안 최신동향']
        
st.session_state['sub_domain'] = st.selectbox(
    "세부 분야를 선택해주세요.",
    sub_domain_list,)

# 4. 출제 기준 선택 (미선택 시 랜덤 설정)
if st.session_state['domain'] == domain_list[0]: # 금융보안일반
    if st.session_state['sub_domain'] == sub_domain_list[0]: # 금융비즈니스
        fs_basic_biz = pd.read_csv('./criteria/fs_basic/biz.csv')
        refer_file_path = "./refer/fs_basic/biz/"
        vectorstore_path = "./data/fs_basic/biz/embedding_data"
        data = fs_basic_biz
    elif st.session_state['sub_domain'] == sub_domain_list[1]: # 금융보안관리체계
        fs_basic_manage = pd.read_csv('./criteria/fs_basic/manage.csv')
        refer_file_path = "./refer/fs_basic/manage/"
        vectorstore_path = "./data/fs_basic/manage/embedding_data"
        data = fs_basic_manage
    elif st.session_state['sub_domain'] == sub_domain_list[2]: # 전자금융보안
        fs_basic_elecfn = pd.read_csv('./criteria/fs_basic/elecfn.csv')
        refer_file_path = "./refer/fs_basic/elecfn/"
        vectorstore_path = "./data/fs_basic/elecfn/embedding_data"
        data = fs_basic_elecfn
    elif st.session_state['sub_domain'] == sub_domain_list[3]: # 개인정보보호
        fs_basic_infosec = pd.read_csv('./criteria/fs_basic/infosec.csv')
        refer_file_path = "./refer/fs_basic/infosec/"
        vectorstore_path = "./data/fs_basic/infosec/embedding_data"
        data = fs_basic_infosec
elif st.session_state['domain'] == domain_list[1]: # 금융보안IT 일반
    if st.session_state['sub_domain'] == sub_domain_list[0]: # 금융IT보안 일반
        fs_it_general = pd.read_csv('./criteria/fs_it/general.csv')
        refer_file_path = "./refer/fs_it/general/"
        vectorstore_path = "./data/fs_it/general/embedding_data"
        data = fs_it_general
    elif st.session_state['sub_domain'] == sub_domain_list[1]: # 금융IT보안 심화
        fs_it_advanced = pd.read_csv('./criteria/fs_it/advanced.csv')
        refer_file_path = "./refer/fs_it/advanced/"
        vectorstore_path = "./data/fs_it/advanced/embedding_data"
        data = fs_it_advanced
elif st.session_state['domain'] == domain_list[2]: # 금융보안법률
    if st.session_state['sub_domain'] == sub_domain_list[0]: # 전자금융
        fs_law_elecfn = pd.read_csv('./criteria/fs_law/elecfn.csv')
        refer_file_path = "./refer/fs_law/elecfn/"
        vectorstore_path = "./data/fs_law/elecfn/embedding_data"
        data = fs_law_elecfn
    elif st.session_state['sub_domain'] == sub_domain_list[1]: # 정보통신
        fs_law_comm = pd.read_csv('./criteria/fs_law/comm.csv')
        refer_file_path = "./refer/fs_law/comm/"
        vectorstore_path = "./data/fs_law/comm/embedding_data"
        data = fs_law_comm
    elif st.session_state['sub_domain'] == sub_domain_list[2]: # 개인정보보호
        fs_law_infosec = pd.read_csv('./criteria/fs_law/infosec.csv')
        refer_file_path = "./refer/fs_law/infosec/"
        vectorstore_path = "./data/fs_law/infosec/embedding_data"
        data = fs_law_infosec
    elif st.session_state['sub_domain'] == sub_domain_list[3]: # 전자서명
        fs_law_elecsign = pd.read_csv('./criteria/fs_law/elecsign.csv')
        refer_file_path = "./refer/fs_law/elecsign/"
        vectorstore_path = "./data/fs_law/elecsign/embedding_data"
        data = fs_law_elecsign
    elif st.session_state['sub_domain'] == sub_domain_list[4]: # 신용정보
        fs_law_credit = pd.read_csv('./criteria/fs_law/credit.csv')
        refer_file_path = "./refer/fs_law/credit/"
        vectorstore_path = "./data/fs_law/credit/embedding_data"
        data = fs_law_credit
elif st.session_state['domain'] == domain_list[3]: # 금융보안 최신동향
    if st.session_state['sub_domain'] == sub_domain_list[0]:
        fs_trend = pd.read_csv('./criteria/fs_trend/2024.csv')
        refer_file_path = "./refer/fs_trend/2024/"
        vectorstore_path = "./data/fs_trend/2024/embedding_data"
        data = fs_trend

# 5. 문제 개수 선택
st.session_state['problem_num'] = st.number_input("생성할 문제 개수를 선택해주세요.", max_value=5, min_value=1, value=1, step=1)

# 6. AI 모델별 호출
if ai_model_type == True:
    if st.session_state['model_option'] == "gpt-3.5": 
        st.session_state['model_option'] = "gpt-3.5-turbo-0125"
    llm = ChatOpenAI(model=st.session_state['model_option'], temperature=0.1, api_key=st.secrets["OPENAI_API_KEY"])
else:
    llm = ChatOllama(model=st.session_state['model_option'], temperature=0.1)

# Tools: 1) google search (used a tavily api)
os.environ["TAVILY_API_KEY"] = st.secrets["TAVILY_API_KEY"]
search = TavilySearchResults(k=3)

tools = [search]

# Tools: 2) Retriever (RAG)
if use_rag == True:
    embeddings = OpenAIEmbeddings()
    
    if os.path.exists(vectorstore_path) != True:
        make_a_embeddingData(refer_file_path, vectorstore_path)
            
    vector = FAISS.load_local(vectorstore_path, embeddings, allow_dangerous_deserialization=True)
    retriever = vector.as_retriever(search_type="similarity")
    retriever_tool = create_retriever_tool(
        retriever,
        name="pdf_search",
        description="""다음과 같은 정보를 검색할 때에는 이 도구를 사용해야 한다:
        - 사용자의 모든 질의에 우선적으로 참고문서를 참조
            
        search the PDF document for keywords that a user entered.
        It serves as a foundational knowledge for generating problems.""",)

    tools = [search, retriever_tool]

prompt = ChatPromptTemplate.from_messages([
    ("system", f"{system_prompt_template}\n\n"),
    ("system", f"[Question generating Guide]\n{instructions}\n\n"),
    ("system", f"[How to write a question]\n{question_example}\n\n"),
    ("system", f"[Condition]\nPast question sample = {refer_questions}\n\n"),
    ("system", f"[Condition]\nDomain = {st.session_state['domain']}\n\n"),
    ("system", f"[Condition]\nSub_domain = {st.session_state['sub_domain']}\n\n"),
    ("user", "{input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad"),
])

agent = create_openai_functions_agent(llm, tools, prompt)
    
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True,
                            return_source_documents=True,
                            return_intermediate_steps=True,)

# 7. 문제 생성

if st.button('문제 생성'):

    with st.spinner("문제 생성 중..."):
        
        data = data.dropna()
        data = data.reset_index(drop=True)

        all_questions = ""

        for index, row in data.iterrows():
        
            st.session_state['search_keyword'] = row.tolist()

            query = f"""Please create exactly {st.session_state['problem_num']} different multiple choice questions based on the {st.session_state['search_keyword']}.
                        While creating questions, you must check whether each question is clearly distinguishable from the others.
                        You must print out each generated problem in the exact same format as below.
                        [Question]
                        [Answer]
                        [Explanation (detailed)]
                        [Refer to, quote]
                        When you create more than one question, [Question] should be [Question 1], [Question 2] and so on.
                        [Answer] must include only one right answer. Options and choices for the question must be in the [Question]"""

            response = agent_executor.invoke({"input": query, 
                                            "agent_scratchpad": [],})

            all_questions += response["output"] + "\n\n"
 
            sleep(1)

        st.session_state.questions = all_questions

        # translate
        # translator = deepl.Translator(st.secrets["DEEPL_API_KEY"])
        # response_ko = translator.translate_text(st.session_state.questions, target_lang="KO")
        # st.session_state.questions = response_ko.text
    
        st.text_area("생성한 문제", value=st.session_state.questions, height=600)

        output_data = st.session_state.questions

        save_to_csv(output_data, st.session_state['domain'], st.session_state['sub_domain'])

    st.info("문제 생성이 완료되었습니다.")
    st.balloons()
