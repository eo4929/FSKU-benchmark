# FSKU 금융보안 문제 풀이 시스템

FSKU 대회 상위 팀들의 전략을 종합하여 구현한 고급 RAG 기반 문제 풀이 시스템입니다.

## 주요 특징

### 1. 모델 구성
- **LLM**: K-intelligence/Midm-2.0-Base-Instruct (KT 믿음 2.0)
- **Embedding**: Qwen/Qwen3-Embedding-0.6B
- **Reranker**: BAAI/bge-reranker-v2-m3

### 2. 핵심 전략

#### Self-Consistency (자기 일관성)
- 동일 질문에 대해 5회 추론 수행
- **객관식**: Majority Voting으로 최다 답변 선택
- **주관식**: TF-IDF 기반 하이브리드 스코어링
  - 점수 = 0.7 × CF(DF_norm) + 0.3 × (1 - IDF_norm)
  - CF: 답변 빈도, IDF: 역문서빈도

#### 법령 전처리
- **조 단위 분할**: 법령을 "제N조" 기준으로 분할
- **Q3 기반 토큰 절단**: 긴 조문은 241토큰으로 제한
- **행정규칙 필터링**: 금융/보안 관련 7개 기관만 선택

#### 2단계 RAG
1. **1단계**: Qwen3-Embedding으로 top-k 문서 검색
2. **2단계**: bge-reranker-v2-m3로 재순위화하여 정확도 향상

#### 프롬프트 최적화
- Reasoning 과정 제거 (성능 향상 확인)
- 객관식: 번호만 출력
- 주관식: 간결한 답변만 출력
- Temperature = 0.0으로 결정론적 생성

### 3. 시스템 구조

```
LawRAGSystem
├── 법령 로딩 및 조 단위 분할
├── Embedding 생성 (Qwen3)
├── FAISS 인덱스 구축
└── Reranker를 통한 2단계 검색

SelfConsistency
├── N회 반복 추론
├── Majority Voting (객관식)
└── Hybrid Scoring (주관식)

Solver
├── 문제 유형 분류
├── RAG 컨텍스트 검색
├── 프롬프트 생성
└── Self-Consistency 적용
```

## 디렉토리 구조

```
FSKU_WWW/
├── 문제 풀이/
│   ├── FSKU_advanced_solve.py  # 고급 솔루션
│   ├── FSKU_solve.py           # 기본 솔루션
│   └── README.md
├── laws/                        # 법령 텍스트 파일
├── administrative_rules/        # 행정규칙 텍스트 파일
├── data/
│   └── test3.csv               # 테스트 데이터
└── 결과보고서/                  # 우수팀 보고서
```

## 사용 방법

### 1. 환경 설정

```bash
pip install torch transformers sentence-transformers faiss-cpu scikit-learn pandas tqdm
```

### 2. 데이터 준비
- `./laws/` 디렉토리에 법령 텍스트 파일 배치
- `./administrative_rules/` 디렉토리에 행정규칙 파일 배치
- `./data/test3.csv` 테스트 데이터 준비

### 3. 실행

```python
python FSKU_advanced_solve.py
```

### 4. 출력 파일
- `submission.csv`: DACON 제출용 파일
- `detailed_results.csv`: 상세 결과 (5회 추론 결과 포함)
- `results_with_context.csv`: 컨텍스트 포함 결과

## 설정 변경

`Config` 클래스에서 주요 파라미터 조정 가능:

```python
class Config:
    LLM_MODEL = "K-intelligence/Midm-2.0-Base-Instruct"
    EMBEDDING_MODEL = "Qwen/Qwen3-Embedding-0.6B"
    RERANKER_MODEL = "BAAI/bge-reranker-v2-m3"

    LAW_MAX_TOKENS = 241      # 법령 조문 최대 토큰
    TOP_K = 10                # 초기 검색 문서 수
    RERANK_TOP_K = 3          # 재순위화 후 문서 수
    N_SAMPLES = 5             # Self-Consistency 샘플 수
    TEMPERATURE = 0.0         # 생성 온도
    MAX_NEW_TOKENS = 256      # 최대 생성 토큰
```

## 상위 팀 전략 요약

### MinuSpurs팀
- 믿음 2.0 Base + BAAI/bge-m3 + FAISS
- 4bit 양자화로 GPU 효율성 확보
- 객관식 번호만, 주관식 간결 답변

### 뛰어팀
- 믿음 2.0 Base-Instruct + Self-Consistency (5회)
- Majority Voting + Hybrid Scoring
- 33개 법령 + 3개 KISA 문서

### Holy팀
- Mi:dm 2.0 Base-Instruct (파인튜닝 없음)
- Qwen3-Embedding-0.6B
- 조 단위 청킹 + Q3 절단 (241토큰)
- Reasoning 제거로 성능 향상

## 성능 최적화 팁

1. **GPU 메모리 부족 시**: 4bit/8bit 양자화 적용
2. **속도 개선**: `N_SAMPLES` 감소 (5→3)
3. **정확도 향상**: `RERANK_TOP_K` 증가, 법령 데이터 추가
4. **긴 문서 처리**: `LAW_MAX_TOKENS` 조정

## 라이선스

FSKU 대회 참가용 코드입니다.
