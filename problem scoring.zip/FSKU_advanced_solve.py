"""
Advanced FSKU Solution Pipeline
상위팀 전략 기반 고급 풀이 시스템

핵심 전략:
1. 한국어 특화 모델 (믿음 2.0 Base 권장)
2. RAG with Reranking (법령 조 단위 분할)
3. Self-Consistency (5회 추론 + 앙상블)
4. 최적화된 프롬프트 (Reasoning 제거)
"""

import os
import re
import json
import pickle
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple
from collections import Counter

import numpy as np
import pandas as pd
from tqdm import tqdm

# RAG & Embedding
from sentence_transformers import SentenceTransformer, CrossEncoder
import faiss

# LLM Inference (HuggingFace Transformers)
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# =====================
# 설정
# =====================
class Config:
    # 데이터 경로
    TEST_PATH = "./data/test3.csv"
    SUB_PATH = "./data/sample_submission3.csv"
    LAW_DIR = "./laws"  # 법령 PDF/텍스트 디렉토리
    ADMRUL_DIR = "./administrative_rules"  # 행정규칙 디렉토리
    OUT_DIR = "./data"

    # 모델 설정
    LLM_MODEL = "K-intelligence/Midm-2.0-Base-Instruct"  # 믿음 2.0
    EMBEDDING_MODEL = "Qwen/Qwen3-Embedding-0.6B"  # 상위팀 사용
    RERANKER_MODEL = "BAAI/bge-reranker-v2-m3"  # 리랭킹

    # RAG 설정
    CHUNK_SIZE = 400  # 토큰 단위 청크
    LAW_MAX_TOKENS = 241  # Q3 기준 절단 (Holy팀)
    TOP_K_RETRIEVAL = 10  # 1차 검색
    TOP_K_RERANK = 5  # 리랭킹 후

    # Self-Consistency 설정
    N_SAMPLES = 5  # 추론 반복 횟수

    # Generation 설정
    MAX_NEW_TOKENS = 256
    TEMPERATURE = 0.0  # 결정론적 생성 (상위팀 권장)
    TOP_P = 1.0
    DO_SAMPLE = False  # 객관식에서는 샘플링 불필요

    # 캐시
    CACHE_DIR = "./cache"
    USE_CACHE = True


# =====================
# 유틸리티 함수
# =====================
def is_multiple_choice(question: str) -> bool:
    """객관식 여부 판단"""
    lines = question.strip().split("\n")
    option_count = sum(1 for line in lines if re.match(r"^\s*[1-5][\.\)]\s+", line))
    return option_count >= 2


def extract_question_and_choices(text: str) -> Tuple[str, List[str]]:
    """객관식에서 질문과 선택지 분리"""
    lines = text.strip().split("\n")
    question_lines = []
    choices = []

    for line in lines:
        if re.match(r"^\s*[1-5][\.\)]\s+", line):
            choices.append(line.strip())
        else:
            question_lines.append(line.strip())

    question = " ".join(question_lines)
    return question, choices


def clean_answer(answer: str, is_mc: bool) -> str:
    """답변 후처리"""
    answer = answer.strip()

    if is_mc:
        # 객관식: 숫자만 추출
        match = re.search(r'\b([1-5])\b', answer)
        if match:
            return match.group(1)
        return "0"  # 실패 시 기본값
    else:
        # 주관식: "답변:" 이후 텍스트만
        if "답변:" in answer:
            answer = answer.split("답변:", 1)[1].strip()
        # 첫 문장만 (마침표까지)
        sentences = re.split(r'[.!?]\s+', answer)
        return sentences[0].strip() if sentences else answer


# =====================
# RAG 시스템
# =====================
class LawRAGSystem:
    """법령 기반 RAG 시스템 (조 단위 분할 + 리랭킹)"""

    def __init__(self, config: Config):
        self.config = config
        self.documents = []
        self.embeddings = None
        self.index = None

        # 모델 로드
        print("Loading embedding model...")
        self.embedding_model = SentenceTransformer(config.EMBEDDING_MODEL)

        print("Loading reranker model...")
        self.reranker = CrossEncoder(config.RERANKER_MODEL)

        self._load_or_build_index()

    def _load_or_build_index(self):
        """캐시된 인덱스 로드 또는 새로 구축"""
        cache_path = Path(self.config.CACHE_DIR)
        cache_path.mkdir(exist_ok=True)

        doc_cache = cache_path / "rag_documents.pkl"
        emb_cache = cache_path / "rag_embeddings.npy"

        if self.config.USE_CACHE and doc_cache.exists() and emb_cache.exists():
            print("Loading cached RAG index...")
            with open(doc_cache, 'rb') as f:
                self.documents = pickle.load(f)
            self.embeddings = np.load(emb_cache)
            self._build_faiss_index()
            print(f"Loaded {len(self.documents)} chunks from cache")
        else:
            print("Building new RAG index...")
            self._build_from_scratch()
            # 캐시 저장
            with open(doc_cache, 'wb') as f:
                pickle.dump(self.documents, f)
            np.save(emb_cache, self.embeddings)
            print(f"Built and cached {len(self.documents)} chunks")

    def _build_from_scratch(self):
        """법령/행정규칙 문서를 조 단위로 분할"""
        # 법령 처리
        law_files = list(Path(self.config.LAW_DIR).glob("**/*.txt"))
        for law_file in tqdm(law_files, desc="Processing laws"):
            self._process_law_file(law_file)

        # 행정규칙 처리 (금융보안 관련 기관만)
        admrul_files = list(Path(self.config.ADMRUL_DIR).glob("**/*.txt"))
        for admrul_file in tqdm(admrul_files, desc="Processing admin rules"):
            self._process_admrul_file(admrul_file)

        # 임베딩 생성
        print("Encoding embeddings...")
        texts = [doc["content"] for doc in self.documents]
        self.embeddings = self.embedding_model.encode(
            texts,
            show_progress_bar=True,
            normalize_embeddings=True
        )

        self._build_faiss_index()

    def _process_law_file(self, file_path: Path):
        """법령 파일을 조 단위로 분할"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 조 단위로 분할 (정규식: 제N조)
        articles = re.split(r'(제\s*\d+\s*조)', content)

        current_article = None
        for i, part in enumerate(articles):
            if re.match(r'제\s*\d+\s*조', part):
                current_article = part
            elif current_article and part.strip():
                # 조 내용
                article_content = f"{current_article} {part.strip()}"

                # Q3 기준 절단 (Holy팀 전략)
                tokens = article_content.split()[:self.config.LAW_MAX_TOKENS]
                truncated_content = " ".join(tokens)

                self.documents.append({
                    "content": truncated_content,
                    "source": file_path.name,
                    "type": "law",
                    "article": current_article
                })

    def _process_admrul_file(self, file_path: Path):
        """행정규칙을 청크로 분할"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 간단한 청크 분할
        words = content.split()
        for i in range(0, len(words), self.config.CHUNK_SIZE // 2):
            chunk = " ".join(words[i:i + self.config.CHUNK_SIZE])
            if chunk.strip():
                self.documents.append({
                    "content": chunk,
                    "source": file_path.name,
                    "type": "administrative_rule"
                })

    def _build_faiss_index(self):
        """FAISS 인덱스 구축"""
        dim = self.embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)  # Inner Product (코사인 유사도)
        self.index.add(self.embeddings.astype('float32'))

    def search(self, query: str, top_k: int = None) -> List[Dict]:
        """쿼리에 대한 관련 문서 검색 + 리랭킹"""
        if top_k is None:
            top_k = self.config.TOP_K_RERANK

        # 1차 검색 (FAISS)
        query_emb = self.embedding_model.encode(
            [query],
            normalize_embeddings=True
        )
        scores, indices = self.index.search(
            query_emb.astype('float32'),
            self.config.TOP_K_RETRIEVAL
        )

        # 후보 문서
        candidates = []
        for score, idx in zip(scores[0], indices[0]):
            if idx >= 0 and idx < len(self.documents):
                doc = self.documents[idx].copy()
                doc['retrieval_score'] = float(score)
                candidates.append(doc)

        # 2차 리랭킹
        if len(candidates) > 0:
            pairs = [[query, doc['content']] for doc in candidates]
            rerank_scores = self.reranker.predict(pairs)

            for doc, rerank_score in zip(candidates, rerank_scores):
                doc['rerank_score'] = float(rerank_score)

            # 리랭크 점수로 재정렬
            candidates.sort(key=lambda x: x['rerank_score'], reverse=True)

        return candidates[:top_k]


# =====================
# LLM 추론 시스템
# =====================
class LLMInference:
    """LLM 추론 엔진"""

    def __init__(self, config: Config):
        self.config = config

        print(f"Loading LLM: {config.LLM_MODEL}")
        self.tokenizer = AutoTokenizer.from_pretrained(config.LLM_MODEL)
        self.model = AutoModelForCausalLM.from_pretrained(
            config.LLM_MODEL,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True
        )
        self.model.eval()

    def generate(self, prompt: str) -> str:
        """텍스트 생성"""
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=self.config.MAX_NEW_TOKENS,
                temperature=self.config.TEMPERATURE,
                top_p=self.config.TOP_P,
                do_sample=self.config.DO_SAMPLE,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id
            )

        generated = self.tokenizer.decode(outputs[0], skip_special_tokens=True)

        # 프롬프트 부분 제거
        if prompt in generated:
            generated = generated.replace(prompt, "").strip()

        return generated


# =====================
# 프롬프트 빌더
# =====================
class PromptBuilder:
    """최적화된 프롬프트 생성 (Reasoning 제거)"""

    @staticmethod
    def build_mc_prompt(question: str, choices: List[str], context: str = "") -> str:
        """객관식 프롬프트 (번호만 출력)"""
        context_section = ""
        if context:
            context_section = f"\n\n[참고 법령]\n{context}\n"

        choices_text = "\n".join(choices)

        return f"""당신은 금융보안 전문가입니다.{context_section}
질문: {question}

선택지:
{choices_text}

정답 선택지 번호만 출력하세요.
답변:"""

    @staticmethod
    def build_subjective_prompt(question: str, context: str = "") -> str:
        """주관식 프롬프트 (간결한 답변)"""
        context_section = ""
        if context:
            context_section = f"\n\n[참고 법령]\n{context}\n"

        return f"""당신은 금융보안 전문가입니다.{context_section}
질문: {question}

간결하고 정확한 답변을 한 문장으로 작성하세요.
답변:"""


# =====================
# Self-Consistency 앙상블
# =====================
class SelfConsistency:
    """Self-Consistency 기법 (여러 번 추론 후 최적 답 선택)"""

    @staticmethod
    def aggregate_mc(answers: List[str]) -> str:
        """객관식: Majority Voting (다수결)"""
        counter = Counter(answers)
        most_common = counter.most_common(1)
        return most_common[0][0] if most_common else answers[0]

    @staticmethod
    def aggregate_subjective(answers: List[str]) -> str:
        """주관식: 키워드 기반 하이브리드 스코어링"""
        if len(answers) == 1:
            return answers[0]

        # 각 답변에서 키워드 추출
        from sklearn.feature_extraction.text import TfidfVectorizer

        vectorizer = TfidfVectorizer(max_features=50)
        try:
            tfidf_matrix = vectorizer.fit_transform(answers)

            # 각 답변의 스코어 계산
            scores = []
            for i, answer in enumerate(answers):
                # 키워드 빈도 (DF)
                keywords = vectorizer.get_feature_names_out()
                word_counts = Counter(answer.split())

                # 공통 키워드 점수
                common_score = sum(
                    word_counts.get(kw, 0) for kw in keywords
                ) / max(len(answer.split()), 1)

                # IDF 점수 (희소성)
                idf_scores = vectorizer.idf_
                avg_idf = np.mean([
                    idf_scores[list(keywords).index(kw)]
                    for kw in word_counts.keys()
                    if kw in keywords
                ]) if any(kw in keywords for kw in word_counts.keys()) else 0

                # 하이브리드 점수 (뛰어팀 전략: 0.7*CF + 0.3*(1-IDF))
                hybrid_score = 0.7 * common_score + 0.3 * (1 - avg_idf / max(idf_scores.max(), 1))
                scores.append(hybrid_score)

            # 최고 점수 답변 선택
            best_idx = np.argmax(scores)
            return answers[best_idx]
        except:
            # TF-IDF 실패 시 첫 번째 답변 반환
            return answers[0]


# =====================
# 메인 파이프라인
# =====================
class FSKUSolver:
    """FSKU 문제 풀이 시스템"""

    def __init__(self, config: Config):
        self.config = config
        self.rag = LawRAGSystem(config)
        self.llm = LLMInference(config)
        self.sc = SelfConsistency()

    def solve_single(self, question: str) -> Dict:
        """단일 질문 풀이"""
        is_mc = is_multiple_choice(question)

        # RAG 검색
        relevant_docs = self.rag.search(question)
        context = "\n".join([
            f"- {doc['content'][:200]}..."
            for doc in relevant_docs[:3]
        ])

        # Self-Consistency: N회 추론
        answers = []
        for _ in range(self.config.N_SAMPLES):
            if is_mc:
                q, choices = extract_question_and_choices(question)
                prompt = PromptBuilder.build_mc_prompt(q, choices, context)
            else:
                prompt = PromptBuilder.build_subjective_prompt(question, context)

            raw_answer = self.llm.generate(prompt)
            cleaned = clean_answer(raw_answer, is_mc)
            answers.append(cleaned)

        # 앙상블
        if is_mc:
            final_answer = self.sc.aggregate_mc(answers)
        else:
            final_answer = self.sc.aggregate_subjective(answers)

        return {
            "answer": final_answer,
            "used_rag": len(relevant_docs) > 0,
            "n_samples": len(answers),
            "is_mc": is_mc
        }

    def solve_batch(self, questions: List[str]) -> List[Dict]:
        """배치 풀이"""
        results = []
        for question in tqdm(questions, desc="Solving questions"):
            result = self.solve_single(question)
            results.append(result)
        return results


# =====================
# 실행
# =====================
if __name__ == "__main__":
    config = Config()

    # 출력 디렉토리 생성
    Path(config.OUT_DIR).mkdir(exist_ok=True)
    Path(config.CACHE_DIR).mkdir(exist_ok=True)

    # 데이터 로드
    print("Loading test data...")
    test_df = pd.read_csv(config.TEST_PATH)

    # 시스템 초기화
    print("Initializing FSKU solver...")
    solver = FSKUSolver(config)

    # 추론
    print(f"Processing {len(test_df)} questions...")
    results = solver.solve_batch(test_df["Question"].tolist())

    # 결과 저장
    submission = test_df[["ID"]].copy() if "ID" in test_df.columns else pd.DataFrame({"ID": range(len(test_df))})
    submission["Answer"] = [r["answer"] for r in results]

    # 메타데이터 포함 버전
    submission["UsedRAG"] = [r["used_rag"] for r in results]
    submission["NSamples"] = [r["n_samples"] for r in results]
    submission["IsMC"] = [r["is_mc"] for r in results]

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 저장
    meta_path = Path(config.OUT_DIR) / f"submission_advanced_{timestamp}.csv"
    submission.to_csv(meta_path, index=False, encoding="utf-8-sig")

    # DACON 제출용 (ID + Answer만)
    dacon_path = Path(config.OUT_DIR) / f"submission_dacon_{timestamp}.csv"
    submission[["ID", "Answer"]].to_csv(dacon_path, index=False, encoding="utf-8-sig")

    print("Done!")
    print(f"  - Metadata version: {meta_path}")
    print(f"  - DACON submission: {dacon_path}")
